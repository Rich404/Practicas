<!DOCTYPE html>
<html lang="es">
<head>  
    <meta charset="UTF-8">
    <title> Acceso - Control Escolar </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
        <link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet"> 
</head>
<body>

    <div class="container">

      <!-- The justified navigation menu is meant for single line per list item.
           Multiple lines will require custom code not provided by Bootstrap. -->
      <div class="masthead">
        <h3 class="text-muted">Control Escolar</h3>
        <nav>
          <ul class="nav nav-justified">
            <li class="nav-item"><a class="nav-link active" href="#">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="#">Alumnos</a></li>
            <li class="nav-item"><a class="nav-link" href="#">Tramites</a></li>
            <li class="nav-item"><a class="nav-link" href="#">Consultas</a></li>
            <li class="nav-item"><a class="nav-link" href="#">Administradores</a></li>
          </ul>
        </nav>
      </div>

      <!-- Jumbotron -->
      <div class="jumbotron">
        <h1>Control Escolar Home</h1>
        <p class="lead">Aqui Podriamos poner cualquier pendejada o algo sin relevancia por ejemplo una gaceta como imagen o algo asi  muy pendjeo </p>
        <p><a class="btn btn-lg btn-success" href="#" role="button">Ver Gaceta</a></p>
	      <div class="divLogin">
                        <?php
                                $ValtxtUsuario = $_POST['txtUsuario'];
                                $ValtxtPass = $_POST['txtPassword'];
                                echo "Usuario:".$ValtxtUsuario."<br> ";
                                echo "Password:".$ValtxtPass;
                        ?>
              </div>
      </div>

     

</body>
</html>

