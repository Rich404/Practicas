<!DOCTYPE html>
<html lang="es">
<head>  
    <meta charset="UTF-8">
    <title> Acceso - Control Escolar </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
        <link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet"> 
</head>
<body>

<div class="container">

      <!-- The justified navigation menu is meant for single line per list item.
           Multiple lines will require custom code not provided by Bootstrap. -->
      <div class="masthead">
        <h3 class="text-muted">Control Escolar</h3>
        <nav>
          <ul class="nav nav-justified">
            <li class="nav-item"><a class="nav-link active" href="Portal.php">Home</a></li>
            <li class="nav-item"><a class="nav-link" href="Alumnos.php">Alumnos</a></li>
            <li class="nav-item"><a class="nav-link" href="#">Tramites</a></li>
            <li class="nav-item"><a class="nav-link" href="Consultas.php">Consultas</a></li>
            <li class="nav-item"><a class="nav-link" href="#">Administradores</a></li>
          </ul>
        </nav>
      </div>

      <!-- Jumbotron -->
      <div class="jumbotron">
		  <h1> Consultas </h1>
		   <form >
			   
					<div class="form-group">
					  <label class="control-label col-sm-1" for="lblTipoConsulta"> Tipo de Consulta: </label>
						 <div class="col-sm-4">
						  <select class="form-control " name="comboTipoConsulta">
							<option>Alumnos Inscritos</option>
							<option>Bajas de Alumnos</option>
							<option>Documentos de Alumnos</option>				
						  </select>
						 </div>
					</div>
			   
				   <div class="form-group" >  <!---- Ajustar tamaño de text -->
				   <label class="control-label col-sm-1" for="lblId_Clave"> Clave: </label>
						<div class="col-sm-4">
						  <input class="form-control" name="txtId_Clave" type="text"> 
						</div>	
				   </div>
			   
			  	   <div class="form-group" > 
					<button type="submit" class="btn btn-warning"> Ejecutar </button>
					<button type="submit" class="btn btn-default"> Reporte </button>
			       </div>
			   
		  </form>
			 <table class="table table-striped">
				<thead>
				  <tr>
					<th>Columna 1</th>
					<th>Columna 2</th>
					<th>Columna 3</th>
				  </tr>
				</thead>
				<tbody>
				  <tr>
					<td>John</td>
					<td>Doe</td>
					<td>john@example.com</td>
				  </tr>
			  </table>
      </div>
</div>
</body>
</html>