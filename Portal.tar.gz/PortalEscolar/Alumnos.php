<!DOCTYPE html>
<html lang="es">
<head>  
    <meta charset="UTF-8">
    <title> Acceso - Control Escolar </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
        <link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet"> 
</head>
<body>

<div class="container">
      <!-- The justified navigation menu is meant for single line per list item.
           Multiple lines will require custom code not provided by Bootstrap. -->
      <div class="masthead">
        <h3 class="text-muted">Control Escolar</h3>
        <nav>
          <ul class="nav nav-justified">
            <li class="nav-item"><a class="nav-link active" href="Portal.php">Home</a></li>
   			<li class="nav-item"><a class="nav-link" href="#">Inscripcion</a></li>
            <li class="nav-item"><a class="nav-link" href="#">Reinscripcion</a></li>
			<li class="nav-item"><a class="nav-link" href="#">Bajas</a></li>
            <li class="nav-item"><a class="nav-link" href="Consultas.php">Consultas</a></li>
            <li class="nav-item"><a class="nav-link" href="#">Administradores</a></li>
          </ul>
        </nav>
      </div>

      <!-- Jumbotron -->
      <div class="jumbotron">
        <h1>Alumnos</h1>
		 <form  class="form-horizontal">
			 
			<div class="form-group " >  <!---- Ajustar tamaño de text -->
			  <label class="control-label col-sm-2" for="lblId_Alumno"> Clave Alumno: </label>
					<div class="col-sm-4">
					  <input class="form-control" name="txtId_Alumno" type="text"> 
					</div>	
			</div>
			 
			 <div class="form-group " >  <!---- Ajustar tamaño de text -->
			  <label class="control-label col-sm-2" for="lblNombre"> Nombre: </label>
					<div class="col-sm-6">
					  <input class="form-control" name="txtNombre" type="text"> 
					</div>	
			</div>
			 
			 <div class="form-group"> 
				<div class="col-sm-offset-2 col-sm-2">
				  <div class="checkbox">
					<label><input  type="checkbox" name="chbxStatus" value="true" checked > Status </label>
				  </div>
				</div>
			 </div>
			 
			  <div class="form-group " >  <!---- Ajustar tamaño de text -->
			  <label class="control-label col-sm-2" for="lblGrado"> Grado: </label>
					<div class="col-sm-1">
					  <input readonly="true" class="form-control" name="txtGrado" type="text" value="5to"> 
					</div>	
			 </div>
			 
			 <div class="form-group">
			  <label class="control-label col-sm-2" for="lblGrupo"> Grupo:</label>
			     <div class="col-sm-1">
				  <select class="form-control " name="comboGrupo">
					<option>A</option>
					<option>B</option>
				  </select>
				 </div>
			</div>
			 
		    <div class="form-group " >  <!---- Ajustar tamaño de text -->
			  <label class="control-label col-sm-2" for="lblEdad"> Edad: </label>
					<div class="col-sm-1">
					  <input class="form-control" name="txtEdad" type="text"> 
					</div>	
			</div>
			 
			<div class="form-group">
			  <label class="control-label col-sm-2" for="lblTipoSangre"> Tipo de Sangre: </label>
			     <div class="col-sm-4">
				  <select class="form-control " name="comboTipoSangre">
					<option>Tipo A</option>
					<option>Tipo B</option>
					<option>Tipo AB</option>
					<option>Tipo O</option>
				  </select>
				 </div>
			</div>

		    <div class="form-group " >  <!---- Ajustar tamaño de text -->
			  <label class="control-label col-sm-2" for="lblSexo"> Sexo: </label>
					<div class="col-sm-4">
					  <input readonly="true" class="form-control" name="txtSexo" type="text" value="Femenino"> 
					</div>	
			 </div>
			 
			 
			<div class="form-group " >  <!---- Ajustar tamaño de text -->
			  <label class="control-label col-sm-2" for="lblDomicilio"> Domicilio: </label>
					<div class="col-sm-4">
					  <textarea class="form-control" rows="5" name="txtDomicilio"></textarea>
					</div>	
			 </div>
			 
			 <div class="form-group " >  <!---- Ajustar tamaño de text -->
			  <label class="control-label col-sm-2" for="lblAlergia"> Alergia: </label>
					<div class="col-sm-4">
					  <input class="form-control" name="txtAlergia" type="text"> 
					</div>	
			</div>
			 
			 <div class="form-group" >
				 <div class="col-sm-offset-2 col-sm-10">
					  <button type="submit" class="btn btn-primary"> Guardar Cambios </button>
				 </div>
			 </div>
			 
		 </form>
      </div>
</div>
</body>
</html>