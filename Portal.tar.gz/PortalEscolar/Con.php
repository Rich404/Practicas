				
			 	<?php
						$con = mysqli_connect("localhost","root","0000","ControlEscolar");

						// Check connection
						if (mysqli_connect_errno())
						{
						  echo "Failed to connect to MySQL: " . mysqli_connect_error();
						}
						else
						{
							echo "OKay prro";	
						}
					mysqli_close($conn);
                ?>
