<!DOCTYPE html>
<html lang="es">
<head>  
    <meta charset="UTF-8">
    <title> ConsultasTable </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
        <link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet"> 
</head>
<body>

<div class="container">
	<h1>Resultados: </h1>
	<?php
	
   		echo"<table class=\"table table-striped\">
				<thead>
				  <tr>
					<th>Columna 1</th>
					<th>Columna 2</th>
					<th>Columna 3</th>
					<th>Columna Action</th>
				  </tr>
				</thead>
				 <!----------- Se establecera Un  Array  a \"n\" para estas etiquetas de  Rows o regsitros para unificar cada registro y asi hacer funcionar correctamente la funcion ShowRows(params)-->
				<tbody>
				  <tr>
					<td id=\"Name0\">Harry</td>
					<td id=\"Other0\">Song</td>
					<td id=\"Mail0\">macharry@example.com</td>
					<td><button onclick=\"ShowRows('Name0','Mail0')\" type=\"submit\" class=\"btn btn-default\"> Reporte </button></td>
				  </tr>
				  <tr>
					<td id=\"Name1\">Jho</td>
					<td id=\"Other1\">Doe</td>
					<td id=\"Mail1\">john@example.com</td>
					<td><button onclick=\"ShowRows('Name1','Mail1')\" type=\"submit\" class=\"btn btn-default\"> Reporte </button></td>
				  </tr>
			  </table>";
	?> 
		 
		 <!-------- Script de javaScript--> 
		<script type="text/javascript">
		function ShowRows(p1,p2){
		//content = document.getElementById(p1);// Get Params
		var Name = document.getElementById(p1).innerHTML
		var Mail = document.getElementById(p2).innerHTML
			
		//alert ("Valor del td: "+content.innerHTML);
		alert ("Name: " + Name + "---- Correo: " + Mail)
		}
		</script>
		  <!-------- -->
</div>
</body>
</html>