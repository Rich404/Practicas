<html lang="es">
<head>  
    <meta charset="UTF-8">
    <title> Acceso - Control Escolar </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
        <link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet"> 
</head>
<body>
<center>
<div class="container">

<?php
	
	$CONEXION = mysqli_connect("localhost","root","0000","ControlEscolar");
		// Check connection
		if (mysqli_connect_errno())
			{
				echo "Error en la Conexion: \n" . mysqli_connect_error();
			}
		else
			{
				//echo "<br><br>Exito en conexion<br>";	
			}
	       		

		
			

	$Type =  $_COOKIE["varType"];
	switch ($Type) 
	{
		case "INSERT":
			//echo "\nOperacion: " . $Type;	
	        $DATA_INSERT = $_GET["NombreGrupo"];
			$sql_insert = "INSERT INTO Grupo (NombreGrupo) VALUES ('".$DATA_INSERT."');";
	    
			if (mysqli_query($CONEXION, $sql_insert)) 
				{
					echo "<br><p>Se ha insertado un nuevo Registro</p>";
					echo "<button  onclick=\"CLOSE()\" type=\"submit\" class=\"btn btn-success\"  > Aceptar </button>";
				} 
			else 
				{
					echo "Error: " . $sql_insert . "<br>" . mysqli_error($CONEXION);
					echo "<button  onclick=\"CLOSE()\" type=\"submit\" class=\"btn btn-danger\"  > Aceptar </button>";
				}

		break;
		case "UPDATE":
			//echo "Operacion: " . $Type;
			$DATA_UPDATE[0] = $_GET["ClaveGrupo"];
			$DATA_UPDATE[1] = $_GET["NombreGrupo"];
			$sql_update = "UPDATE Grupo SET NombreGrupo='".$DATA_UPDATE[1]."' WHERE Id_Grupo = ". $DATA_UPDATE[0].";";
			if (mysqli_query($CONEXION, $sql_update)) 
				{
					echo "<br><p>Se ha Actualizado un Registro</p>";
					echo "<button  onclick=\"CLOSE()\" type=\"submit\" class=\"btn btn-success\"  > Aceptar </button>";
				} 
			else 
				{
					echo "Error: " . $sql_update . "<br>" . mysqli_error($CONEXION);
					echo "<button  onclick=\"CLOSE()\" type=\"submit\" class=\"btn btn-danger\"  > Aceptar </button>";
				}
		break;
		case "DELETE":
			//echo "Operacion: " . $Type;
			$DATA_DELETE = $_GET["ClaveGrupo"];
			$sql_delete = "DELETE FROM Grupo WHERE Id_Grupo = ". $DATA_DELETE." ;";
			if (mysqli_query($CONEXION, $sql_delete)) 
				{
					echo "<br><p>Se ha Eliminado Un Registro</p>";
					echo "<button  onclick=\"CLOSE()\" type=\"submit\" class=\"btn btn-success\"  > Aceptar </button>";
				} 
			else 
				{
					echo "Error: " . $sql_delete . "<br>" . mysqli_error($CONEXION);
					echo "<button  onclick=\"CLOSE()\" type=\"submit\" class=\"btn btn-danger\"  > Aceptar </button>";
				}
		break;
	}
	
	mysqli_close($conn);
?>
<script type="text/javascript">
	function CLOSE()
	{
		window.close();
	}
</script>
</div>
</center>
</body>
</html>
