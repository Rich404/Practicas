<!DOCTYPE html>
<html lang="es">
<head>  
    <meta charset="UTF-8">
    <title> Acceso - Control Escolar </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
        <link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet"> 
</head>
<body>

<div class="container">

      <!-- The justified navigation menu is meant for single line per list item.
           Multiple lines will require custom code not provided by Bootstrap. -->
      <div class="masthead">
        <h3 class="text-muted">Control Escolar</h3>
        <nav>
          <ul class="nav nav-justified">
            <li class="nav-item"><a class="nav-link active" href="Portal.php">Home</a></li>
   			<li class="nav-item"><a class="nav-link" href="#">Inscripcion</a></li>
            <li class="nav-item"><a class="nav-link" href="#">Reinscripcion</a></li>
			<li class="nav-item"><a class="nav-link" href="#">Bajas</a></li>
            <li class="nav-item"><a class="nav-link" href="Consultas.php">Consultas</a></li>
            <li class="nav-item"><a class="nav-link" href="#">Administradores</a></li>
			<li class="nav-item"><a class="nav-link" href="Grupos.php">Mantto Grupos</a></li>
          </ul>
        </nav>
      </div>

      <!-- Jumbotron -->
      <div class="jumbotron">
		  <h1> Consultas de Alumnos </h1>
		  <div class="pull-right">
		  	<button type="button" onclick="ChangeIframe()" class="btn btn-warning"  > Ejecutar </button>
		  </div>
		   <form>
					<div class="form-group">
						<label class="control-label col-sm-1" for="lblTipoConsulta"> Grado: </label>
						 <div class="col-sm-1">
						  <select class="form-control " name="comboTipoConsulta">
							<option></option>
							<option>1ro</option>	
							<option>2do</option>	
							<option>3ro</option>
							<option>4to</option>	
							<option>5to</option>	
							<option>6to</option>
						  </select>
						 </div>
						<label class="control-label col-sm-1" for="lblTipoConsulta"> Grupo: </label> <!-- Esto se llenará con PhP y solo esto es la razón de que la pag, sea .php -->
						 <div class="col-sm-1">
						  <select class="form-control " name="comboTipoConsulta">
							 <option></option>
							<option>A</option>	
							<option>B</option>	
						  </select>
						 </div>
						<label class="control-label col-sm-1" for="lblTipoConsulta"> Filtro de Relacion: </label>
						 <div class="col-sm-2">
						  <select class="form-control " name="comboTipoConsulta">
							<option></option>
							<option>Documentos</option>
							<option>Tutor</option>	
						  </select>
						 </div>
						
						<div class="col-sm-1">
						<label><input  type="checkbox" name="chbxStatus" value="true" checked > Status </label>
						</div>
					</div>
				   <div class="form-group" >  <!---- Ajustar tamaño de text -->
				   <label class="control-label col-sm-1" for="lblId_Clave"> Clave: </label>
						<div class="col-sm-2">
						  <input class="form-control" name="txtId_Clave" type="text"> 
						</div>	
				   </div>
			  	<br>
			   	<br>
			  
		  </form>
		  
		  
		  <br>
		  <br>
			 
		   <!---  Iframe que guarda otra pagina.php peor que se le enviarán los parametros por medio del url -->
		  <div class="embed-responsive embed-responsive-16by9 ">
			<iframe name="frmInternal" class="embed-responsive-item" src="Resultados.php"></iframe>
		  </div>
		  <!-------- Script de javaScript Para cambiar o actualizar el contenido que regresará dependiendo de los parametros del form anterior--> 
			<script type="text/javascript">
				function ChangeIframe(){
					
						window.frames["frmInternal"].location = "http://www.w3schools.com/jsref";
						//window.frames["frmInternal"].location.reload();
				}
			</script>
		  <!-------- -->
		  
		
		  
		 
		  
      </div>
</div>
</body>
</html>