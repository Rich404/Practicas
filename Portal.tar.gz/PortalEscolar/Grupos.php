<html lang="es">
<head>  
    <meta charset="UTF-8">
    <title> Acceso - Control Escolar </title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
        <link href="https://fonts.googleapis.com/css?family=ABeeZee" rel="stylesheet"> 
</head>
<body>

<div class="container">

      <!-- The justified navigation menu is meant for single line per list item.
           Multiple lines will require custom code not provided by Bootstrap. -->
      <div class="masthead">
        <h3 class="text-muted">Control Escolar</h3>
        <nav>
          <ul class="nav nav-justified">
            <ul class="nav nav-justified">
				<li class="nav-item"><a class="nav-link active" href="Portal.php">Home</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Inscripcion</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Reinscripcion</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Bajas</a></li>
				<li class="nav-item"><a class="nav-link" href="Consultas.php">Consultas</a></li>
				<li class="nav-item"><a class="nav-link" href="#">Administradores</a></li>
				<li class="nav-item"><a class="nav-link" href="Grupos.php">Mantto Grupos</a></li>
			</ul>
          </ul>
        </nav>
      </div>

      <!-- Jumbotron -->
      <div class="jumbotron">
		  <h1>Mantenimiento Grupos</h1>
		  
		  <label class="pull-left col-sm-1" for="lblNombreGrupo"> Nombre: </label>
			<div class="col-sm-2 pull-left">
				<input class="form-control" id="txtNombreGrupo" type="text"> 
		    </div>
		  <div class="pull-left">
		  	     <button  onclick="INSERT('txtNombreGrupo')" type="submit" class="btn btn-primary"  > Añadir Grupo </button> 
		  </div>
		  
		  
		  	<form  class="form-horizontal" >
				
			 	<?php
									 	
						$CONEXION = mysqli_connect("localhost","root","0000","ControlEscolar");
						$sql = "SELECT * FROM Grupo;";
						// Check connection
						if (mysqli_connect_errno())
						{
						  echo "Failed to connect to MySQL: " . mysqli_connect_error();
						}
						else
						{
							echo "<br><br>Exito en conexion";	
						}
						
						

						echo "<table class=\"table table-striped\">
							<thead>
							  <tr>
								<th>Clave Grupo</th>
								<th>Nombre Grupo</th>
								<th>Eliminar</th>
								<th>Actualizar</th>
							  </tr>
							</thead>
							<tbody> ";

						$i=1; // Contador ParaIDdeRows
						$result = mysqli_query($CONEXION, $sql);
						if (mysqli_num_rows($result) > 0) 
						{
							// output data of each row
							while($row = mysqli_fetch_assoc($result)) 
							{
								//echo "<br>Id_Grupo:" . $row["Id_Grupo"]. "  NombreGrupo:" . $row["NombreGrupo"]."<br>";
								echo "<tr>"."<td id=\"ClaveGrupo$i\">". $row["Id_Grupo"] ."</td>"."<td id=\"Nombre$i\">". $row["NombreGrupo"] ."</td>"."<td><button onclick=\"UPDATE('ClaveGrupo$i')\" type=\"submit\" class=\"btn btn-default\"> Editar </button></td>"."<td><button onclick=\"DELETE('ClaveGrupo$i')\" type=\"submit\" class=\"btn btn-default\"> Eliminar </button></td>"."</tr>";
							    $i++;
							}
							
						} 
					    else 
						{
							echo "<p>No Hay Registros a mostrar</p>";
						}

						mysqli_close($conn);	
						echo"</table>";
						 /*echo "<table class=\"table table-striped\">
							<thead>
							  <tr>
								<th>Clave Grupo</th>
								<th>Nombre Grupo</th>
								<th>Eliminar</th>
								<th>Actualizar</th>
							  </tr>
							</thead>
							<tbody>
							  <tr>
								<td id=\"ClaveGrupo0\">1</td>
								<td id=\"Nombre0\">A</td>
								<td><button onclick=\"DELETE('ClaveGrupo0','Nombre0')\" type=\submit\" class=\"btn btn-default\"> Eliminar </button></td>
								<td><button onclick=\"UPDATE('ClaveGrupo0','Nombre0')\" type=\submit\" class=\"btn btn-default\"> Editar </button></td>
							  </tr>
						  </table>";  */


                ?>
				 <!-------- Script de javaScript--> 
				<script type="text/javascript">
					function DELETE(p1)
					{
						//content = document.getElementById(p1);// Get Params

						var ClaveGrupo = document.getElementById(p1).innerHTML//
						//var Nombre = document.getElementById(p2).innerHTML
						var Type = "DELETE";

						//alert ("Valor del td: "+content.innerHTML);
						//alert ("ELIMINAR --- Clave: "+ ClaveGrupo + "Nombre:"+ Nombre)

						document.cookie ='varType='+ Type +'; expires=Thu, 2 Aug 2021 12:00:00 UTC; path=/';
						window.open("querySqlGrupo.php?ClaveGrupo=" + ClaveGrupo , "GrupoQuerySQL" , "width=400,height=200,scrollbars=NO,left=400,top=200") 
						

					}	
					function UPDATE(p1)
					{
					//content = document.getElementById(p1);// Get Params
						var ClaveGrupo = document.getElementById(p1).innerHTML//
						var Nombre = prompt("Nuevo nombre de Grupo")
						var Type = "UPDATE";//	
						//alert ("Valor del td: "+content.innerHTML);
						//alert ("ACTUALIZAR --- Clave: "+ ClaveGrupo + "Nombre:"+ Nombre)


							//window.frames["frmInternal"].location = "http://www.w3schools.com/jsref";
							//window.frames["frmInternal"].location.reload();
							document.cookie ='varType='+ Type +'; expires=Thu, 2 Aug 2021 12:00:00 UTC; path=/';
							window.open("querySqlGrupo.php?ClaveGrupo=" + ClaveGrupo + "&NombreGrupo=" + Nombre , "GrupoQuerySQL" , "width=400,height=200,scrollbars=NO,left=400,top=200") 
					}
					function INSERT(p1)
					{
						var  Nombre = document.getElementById(p1).value
						//alert ("Valor de Text: " + Nombre )
						var Type = "INSERT";//
						//var hello = "hello";
    					//var world = "world";
						//window.frames["frmInternal"].location = "http://www.w3schools.com/jsref";
						//window.frames["frmInternal"].location.reload();
						document.cookie ='varType='+ Type +'; expires=Thu, 2 Aug 2021 12:00:00 UTC; path=/';
						window.open("querySqlGrupo.php?NombreGrupo=" + Nombre, "GrupoQuerySQL" , "width=400,height=200,scrollbars=NO,left=400,top=200") 
								  //"somepage.php?w1=" + hello + "&w2=" + world;
						document.location.href = document.location.href; // truco para recargar asi mismo toda la pag. Es to por que los elementos de este funcion no estan ligados a un form que haga un reload.

				    }

				</script>
			 
		 </form>
      </div>
</div>
</body>
</html>